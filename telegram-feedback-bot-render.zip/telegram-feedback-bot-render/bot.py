import os
import gspread
import schedule
import time
import base64
import pytz
from email.mime.text import MIMEText
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import (
    ApplicationBuilder, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes, ConversationHandler
)
from datetime import datetime, timedelta
import threading

# === CONFIG ===
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "959060927").split(",")]
ADMIN_EMAILS = os.getenv("ADMIN_EMAILS", "mingjasky01@gmail.com").split(",")
SHEET_NAME = "Telegram 回報系統 (每週報告版)"
TIMEZONE = pytz.timezone("Asia/Taipei")

# === GOOGLE API ===
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/gmail.send"
]
creds = Credentials.from_service_account_file("credentials.json", scopes=SCOPES)
gc = gspread.authorize(creds)

# === SHEET 初始化 ===
def setup_google_sheet(sheet_name):
    for spreadsheet in gc.list_spreadsheet_files():
        if spreadsheet["name"] == sheet_name:
            print(f"✅ 已找到試算表: {sheet_name}")
            return gc.open(sheet_name)

    print(f"📄 未找到試算表，建立中: {sheet_name}")
    service = build("sheets", "v4", credentials=creds)
    spreadsheet = service.spreadsheets().create(
        body={"properties": {"title": sheet_name}},
        fields="spreadsheetId"
    ).execute()

    spreadsheet_id = spreadsheet.get("spreadsheetId")
    sh = gc.open_by_key(spreadsheet_id)
    main_sheet = sh.sheet1
    main_sheet.update_title("回報紀錄")
    main_sheet.append_row(["時間戳記", "用戶名稱", "用戶ID", "語言", "類別", "回報內容"])

    summary = sh.add_worksheet(title="統計報表", rows=20, cols=5)
    summary.update("A1", "📊 回報統計報表")
    summary.update("A3:E3", [["日期", "總回報數", "Bug", "建議", "其他"]])

    print(f"✅ 已建立新試算表並包含統計頁面: {sheet_name}")
    return sh

spreadsheet = setup_google_sheet(SHEET_NAME)
sheet = spreadsheet.worksheet("回報紀錄")

# === 語言設定 ===
CHOOSING_LANG, CHOOSING_CATEGORY, TYPING_REPORT = range(3)
TEXTS = {
    "zh": {
        "welcome": "👋 歡迎使用回報系統！請選擇語言 / Please select language：",
        "choose_category": "請選擇回報類別：",
        "categories": [
            ("🐞 Bug 回報", "bug"),
            ("💡 功能建議", "suggestion"),
            ("📝 其他", "other")
        ],
        "enter_report": "請輸入您的回報內容：",
        "thank_you": "✅ 已收到您的回報，感謝您的回饋！",
        "cancel": "已取消操作。"
    },
    "en": {
        "welcome": "👋 Welcome to the Feedback Bot! Please select your language:",
        "choose_category": "Please choose your feedback category:",
        "categories": [
            ("🐞 Bug Report", "bug"),
            ("💡 Feature Suggestion", "suggestion"),
            ("📝 Other", "other")
        ],
        "enter_report": "Please type your feedback below:",
        "thank_you": "✅ Your feedback has been received. Thank you!",
        "cancel": "Operation canceled."
    }
}

# === Telegram handlers ===
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("中文 🇹🇼", callback_data="lang_zh")],
        [InlineKeyboardButton("English 🇬🇧", callback_data="lang_en")]
    ]
    await update.message.reply_text(TEXTS["zh"]["welcome"], reply_markup=InlineKeyboardMarkup(keyboard))
    return CHOOSING_LANG

async def choose_language(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    lang = query.data.split("_")[1]
    context.user_data["lang"] = lang
    texts = TEXTS[lang]
    keyboard = [[InlineKeyboardButton(text, callback_data=code)] for text, code in texts["categories"]]
    await query.edit_message_text(texts["choose_category"], reply_markup=InlineKeyboardMarkup(keyboard))
    return CHOOSING_CATEGORY

async def choose_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    category = query.data
    context.user_data["category"] = category
    lang = context.user_data["lang"]
    await query.edit_message_text(TEXTS[lang]["enter_report"])
    return TYPING_REPORT

async def receive_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    text = update.message.text
    lang = context.user_data.get("lang", "zh")
    category = context.user_data.get("category", "other")
    local_time = datetime.now(TIMEZONE).strftime("%Y-%m-%d %H:%M:%S")

    sheet.append_row([
        local_time,
        f"{user.first_name} (@{user.username})",
        str(user.id),
        lang,
        category,
        text
    ])

    for admin_id in ADMIN_IDS:
        await context.bot.send_message(
            chat_id=admin_id,
            text=f"📩 新回報\n\n"
                 f"👤 用戶：{user.first_name} (@{user.username})\n"
                 f"🆔 ID：{user.id}\n"
                 f"🌐 語言：{lang}\n"
                 f"🏷 類別：{category}\n"
                 f"💬 內容：{text}\n"
                 f"🕓 時間：{local_time} (Asia/Taipei)"
        )

    await update.message.reply_text(TEXTS[lang]["thank_you"])
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang = context.user_data.get("lang", "zh")
    await update.message.reply_text(TEXTS[lang]["cancel"])
    return ConversationHandler.END

# === 每週寄信功能 ===
def send_weekly_report():
    try:
        records = sheet.get_all_records()
        if not records:
            print("📭 沒有新的回報。")
            return

        now = datetime.now(TIMEZONE)
        week_ago = now - timedelta(days=7)
        recent = [r for r in records if datetime.strptime(r["時間戳記"], "%Y-%m-%d %H:%M:%S") > week_ago]

        total = len(recent)
        bugs = sum(1 for r in recent if r["類別"] == "bug")
        suggestions = sum(1 for r in recent if r["類別"] == "suggestion")
        others = sum(1 for r in recent if r["類別"] == "other")

        report_text = f"""
📊 每週回報統計報告 ({week_ago.strftime('%Y-%m-%d')} ~ {now.strftime('%Y-%m-%d')})
-------------------------------------------------
總回報數：{total}
🐞 Bug：{bugs}
💡 建議：{suggestions}
📝 其他：{others}
-------------------------------------------------
📅 寄出時間（台北）：{now.strftime('%Y-%m-%d %H:%M:%S')}
📄 查看完整紀錄：
https://docs.google.com/spreadsheets/d/{spreadsheet.id}
"""

        service = build("gmail", "v1", credentials=creds)
        for email in ADMIN_EMAILS:
            message = MIMEText(report_text)
            message["to"] = email
            message["subject"] = f"每週 Telegram 回報統計報告 ({now.strftime('%Y-%m-%d')})"
            encoded_message = base64.urlsafe_b64encode(message.as_bytes()).decode()
            service.users().messages().send(userId="me", body={"raw": encoded_message}).execute()

        print(f"✅ 已寄出每週報告 ({now})")

    except Exception as e:
        print(f"❌ 寄信失敗: {e}")

# === 排程 ===
schedule.every().monday.at("09:00").do(send_weekly_report)

def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(60)

# === 主程式 ===
def main():
    threading.Thread(target=run_scheduler, daemon=True).start()

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            CHOOSING_LANG: [CallbackQueryHandler(choose_language)],
            CHOOSING_CATEGORY: [CallbackQueryHandler(choose_category)],
            TYPING_REPORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_report)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )

    app.add_handler(conv_handler)
    print("🤖 Bot running... weekly report every Monday 09:00 (Asia/Taipei)")
    app.run_polling()

if __name__ == "__main__":
    main()
